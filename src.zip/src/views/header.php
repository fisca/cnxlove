            <header id="header">

                <hgroup>
                    <h1 id="site-logo"><a href="#">CNXLOVE.com</a></h1>
                    <h2 id="site-description">Site Description</h2>
                </hgroup>

                <nav>
                    <ul id="main-nav" class="clearfix">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Service</a> </li>
                        <li><a href="#">Contact us</a></li>
                    </ul>
                    <!-- /#main-nav --> 
                </nav>

                <form id="searchform">
                    <input type="search" id="s" placeholder="Search">
                </form>

            </header>
            <!-- /#header -->