            <footer id="footer">

                <p>&copy; 2012-<?php echo date('Y'); ?> cnxlove.com.
                    Thanks for responsive design by <a href="http://webdesignerwall.com" target="_blank" style="color: #ccc;">Web Designer Wall</a></p>

            </footer>
            <!-- /#footer -->