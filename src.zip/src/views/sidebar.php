            <aside id="sidebar">

                <section class="widget">
                    <h4 class="widgettitle">Sidebar</h4>
                    <ul>
                        <li><a href="#">WordPress</a> (3)</li>
                        <li><a href="#">Design</a> (23)</li>
                        <li><a href="#">Design </a>(18)</li>
                    </ul>
                </section>
                <!-- /.widget -->

                <section class="widget clearfix">
                    <h4 class="widgettitle">Flickr</h4>
                    <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=8.&display=latest&size=s&layout=x&source=user&user=52839779@N02"></script> 
                </section>
                <!-- /.widget -->

            </aside>
            <!-- /#sidebar -->