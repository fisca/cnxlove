<?php
header("Location: home.php");
//echo "Hello World ";
?>